package net.example.duan1_nhom1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DanhSachHoaDonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_hoa_don);
    }
}