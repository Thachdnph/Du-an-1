package net.example.duan1_nhom1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DanhSachSanPhamActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_san_pham);
    }
}